package com.austin.Oshop.exceptions.common;

/**
 * @author BENARD AUGUSTINE ADAKOLE
 * @created on 25/Sep/2022 - 11:57 PM
 * @project Oshop
 */
public class AlreadyExistException extends Exception {
    public AlreadyExistException(String message) {
        super(message);
    }

}
