package com.austin.Oshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
